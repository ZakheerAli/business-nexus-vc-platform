# 💎 Business Nexus — Venture Dealflow & SAFE Cap Table Operating System

An institutional-grade venture capital dealflow exchange and startup fundraising platform connecting high-growth entrepreneurs with verified check-writers. Features algorithmic thesis matching, interactive post-money SAFE cap table dilution modeling, confidential watermarked data room vaults, and an animated AI Venture Co-Pilot with full bilingual support (English & Roman Urdu).

---

## 🌟 Key Features

- **Institutional Landing Page:**
  - High-impact cyber-luxe aesthetic (Deep Velvet Obsidian `#04060C` + 24K Liquid Aurum Gold + Jade Emerald).
  - 1-Click instant test drive for dual personas (Victoria Sterling / Peak Horizon Capital vs Marcus Chen / SynthFlow AI).
  - Live Venture Pulse transaction ticker ribbon.
- **Interactive Post-Money SAFE Dilution Modeler:**
  - Real-time dilution calculations adhering to Y-Combinator and NVCA standards.
  - Interactive sliders for Capital Raise, Post-Money Valuation Cap, and Pre-Round Founder Equity.
  - Mathematical equity breakdown (Founders %, New Investors %, Option Pool %).
- **Confidential Data Room Vaults:**
  - Forensic dynamic watermarking with viewer email, timestamp, and IP address.
  - Instant founder killswitch for access revocation.
  - AES-256 storage and automated NDA gating.
- **Full Bilingual Support (English & Roman Urdu):**
  - Seamless 1-click language switcher (`🌐 EN | Roman Urdu`) across both the landing page and dashboard.
- **Nexus AI Venture Co-Pilot:**
  - Floating holographic animated assistant powered by `@google/genai` (`gemini-3.8-flash`).
  - Analyzes active startup rounds, explains cap table dilution, and provides bilingual venture intelligence.
- **Spotlight Command Palette:**
  - Global `⌘K` / `Ctrl+K` keyboard shortcut for fast navigation across startups, diligence rooms, and syndicates.

---

## 🛠️ Tech Stack

- **Frontend:** React 19, TypeScript 5.8+, Vite 8
- **Styling:** Tailwind CSS v4, Cyber-Velvet & Liquid Aurum design system
- **Animations:** Framer Motion (`motion/react` v12)
- **Icons:** Lucide React
- **Routing:** React Router DOM v7
- **AI Engine:** Google Gemini 3.8 Flash (`@google/genai`)
- **Backend:** Node.js & Express (`server.ts`)

---

## 🚀 Getting Started

### 1. Prerequisites
- **Node.js:** v18+ or v20+ recommended
- **Package Manager:** `npm` or `bun`

### 2. Installation
Clone the repository and install dependencies:
```bash
git clone <YOUR_GITHUB_REPO_URL>
cd business-nexus
npm install
```

### 3. Environment Setup
Copy the example environment configuration:
```bash
cp .env.example .env
```
Add your optional Gemini API key inside `.env`:
```env
GEMINI_API_KEY="your_api_key_here"
```

### 4. Running the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Production Build
```bash
npm run build
npm run start
```

---

## 🔒 Security & Standards

- Delaware C-Corp & NVCA compliant term sheets
- Forensic document watermarking & zero-download leakage protection
- Strict client/server separation for API credentials

---

## 📄 License
Apache-2.0 License.
