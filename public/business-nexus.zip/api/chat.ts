import { GoogleGenAI } from '@google/genai';

// Initialize Google Gen AI client
const aiApiKey = process.env.GEMINI_API_KEY || '';
const ai = aiApiKey
  ? new GoogleGenAI({
      apiKey: aiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    })
  : null;

const PLATFORM_CONTEXT = `
You are Nexus AI, the elite Institutional Venture Capital Co-Pilot and Dealflow Analyst on the Business Nexus platform.
Platform details:
- Business Nexus connects high-growth startup founders and institutional VC check-writers.
- Featured Startups:
  1. SynthFlow AI: Autonomous enterprise workflow engine, $1.2M ARR, +280% YoY growth, raising $2.0M at $10.0M valuation cap, Lead: Accel Scout Syndicate. Founder: Marcus Chen.
  2. QuantumEdge: Quantum-accelerated drug discovery platform, Seed round, raising $3.5M.
  3. BioGenix Labs: Next-gen synthetic biology & gene therapies, $2.5M Target Raise.
  4. EcoSphere: CleanTech enterprise carbon tracking software, Series A.
- Core Features:
  - Interactive Post-Money SAFE Cap Table Dilution Modeler (NVCA & Y-Combinator standards).
  - Confidential Data Room Vaults with AES-256 encryption, dynamic email/IP forensic watermarking, and instant killswitch.
  - Dual Personas: Victoria Sterling (Partner at Peak Horizon Capital, $50M AUM) and Marcus Chen (CEO at SynthFlow AI).
  - Spotlight Command Palette: ⌘K / Ctrl+K.
  - Full bilingual support in both English and Roman Urdu.

Behavior & Tone:
- Answer with institutional precision, executive brevity, and venture acumen.
- If the user writes in Roman Urdu or Urdu, respond naturally in crisp Roman Urdu!
- If the user writes in English, respond in professional executive English.
- Be helpful, friendly, and structured (use bullet points and bold highlights).
`;

function getContextualFallbackResponse(userMessage: string, lang: string): string {
  const query = userMessage.toLowerCase();
  const isUrdu = lang === 'romanUrdu' || query.includes('kya') || query.includes('kaise') || query.includes('batao') || query.includes('hai') || query.includes('mujhe');

  if (query.includes('synthflow') || query.includes('quantumedge') || query.includes('startup') || query.includes('deals')) {
    if (isUrdu) {
      return `**Nexus AI Analysis · Active Startups Dealflow:**\n\n1. **SynthFlow AI (Series A):**\n   - **ARR:** $1.20M (+280% YoY Growth)\n   - **Target Raise:** $2.0M ($1.4M committed)\n   - **Valuation Cap:** $10.0M Post-Money\n   - **Lead:** Accel Scout Syndicate | Founder: Marcus Chen\n\n2. **QuantumEdge (Seed):** $3.5M raise, DeepTech quantum drug discovery.\n\n3. **BioGenix Labs:** $2.5M raise, Confidential Data Room abhi open hai.\n\nAap kisi bhi startup ka Diligence Room explore karne ke lye **Dealflow Radar** ya landing page par inspect button click kar sakte hain!`;
    }
    return `**Nexus AI Analysis · Active Dealflow Snapshot:**\n\n1. **SynthFlow AI (Series A):**\n   - **Traction:** $1.20M ARR (+280% YoY velocity)\n   - **Round:** Raising $2.0M ($1.4M committed) at $10.0M Post-Money Cap\n   - **Lead:** Accel Scout Syndicate | CEO: Marcus Chen\n\n2. **QuantumEdge (Seed):** $3.5M round, quantum computing biotech pipeline.\n\n3. **BioGenix Labs (Series Seed):** $2.5M allocation open with encrypted Data Room.\n\nYou can model any check size on the interactive SAFE calculator or inspect watermarked diligence rooms!`;
  }

  if (query.includes('safe') || query.includes('dilution') || query.includes('valuation') || query.includes('cap table') || query.includes('hisaab')) {
    if (isUrdu) {
      return `**Nexus AI · SAFE Cap Table Dilution Formula:**\n\nPost-Money SAFE mein naye investor ki ownership seedhi calculate hoti hai:\n\n$$\\text{Investor Ownership \\%} = \\frac{\\text{Investment Check}}{\\text{Post-Money Valuation Cap}} \\times 100$$\n\n- **Misaal:** Agar aap **$250,000** invest karein aur Valuation Cap **$10,000,000** ho, to ownership **2.50%** hogi.\n- Pre-round founder equity proportionally adjust hoti hai jabke unallocated option pool محفوظ rehta hai.\n\nAap hamare live **SAFE Modeler** slider se real-time graph dekh sakte hain!`;
    }
    return `**Nexus AI · Post-Money SAFE Dilution Breakdown:**\n\nIn standard YC & NVCA Post-Money SAFEs, new investor ownership is fixed precisely against the valuation cap:\n\n$$\\text{New Investor \\%} = \\frac{\\text{Capital Invested}}{\\text{Post-Money Valuation Cap}} \\times 100$$\n\n- **Example:** A **$250k check** into a **$10.0M Cap** yields an exact **2.50% equity stake**.\n- Founder ownership is calculated as: $\\text{Pre-Round \\%} \\times (1 - \\text{New Investor \\%})$.\n\nYou can use our on-page **SAFE Modeler** to simulate any round scenario dynamically!`;
  }

  if (query.includes('data room') || query.includes('vault') || query.includes('security') || query.includes('hifazat')) {
    if (isUrdu) {
      return `**Nexus AI · Confidential Data Room Security:**\n\nBusiness Nexus ka Data Room institutional grade security standard follow karta hai:\n\n- **Forensic Watermarking:** Har khuli hui pitch deck aur financial model par viewer ka email, date, aur IP address permanently stamp ho jata hai.\n- **Instant Killswitch:** Founder kisi bhi waqt kisi bhi investor ka access 1-click se revoke kar sakta hai.\n- **AES-256 Encryption:** Storage aur transmission dono encrypted hain with automated digital NDAs.`;
    }
    return `**Nexus AI · Confidential Data Room Architecture:**\n\nOur diligence vaults are designed for institutional-grade protection:\n\n- **Dynamic Forensic Watermark:** Real-time email, timestamp, and IP stamping across every page prevents leaks.\n- **Instant Killswitch:** Founders can revoke document clearance with a single click.\n- **AES-256 Storage & Automated NDAs:** Ensures zero unvetted download leakage.`;
  }

  if (isUrdu) {
    return `Khushamdeed! Main **Nexus AI** hun — aapka Venture Capital aur Startup Fundraising Co-Pilot. \n\nAap mujhse kisi bhi startup ki traction, SAFE cap table dilution, confidential data room, ya NVCA term sheet ke baray mein sawal pooch sakte hain. Main English aur Roman Urdu dono mein madad karne ke lye hazir hun!`;
  }

  return `Welcome to **Nexus AI** — your institutional venture co-pilot and dealflow analyst. Ask me anything about our active startup rounds (SynthFlow AI, QuantumEdge), SAFE dilution mechanics, diligence vaults, or NVCA term sheets!`;
}

export default async function handler(req: any, res: any) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { messages = [], language = 'en' } = req.body || {};
    const lastUserMessage = messages[messages.length - 1]?.content || '';

    if (!lastUserMessage.trim()) {
      return res.status(400).json({ error: 'Message content is required.' });
    }

    if (ai) {
      try {
        const promptMessages = messages.map((m: { role: string; content: string }) => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }]
        }));

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptMessages,
          config: {
            systemInstruction: PLATFORM_CONTEXT + `\nCurrent user interface language preference: ${language}. If the user writes in Roman Urdu or asks for Urdu, always respond in Roman Urdu.`,
            temperature: 0.65,
            maxOutputTokens: 1000
          }
        });

        const reply = response.text || '';
        if (reply) {
          return res.status(200).json({ reply });
        }
      } catch (geminiError: any) {
        console.warn('Gemini API call warning in serverless function:', geminiError?.message || geminiError);
      }
    }

    const fallbackReply = getContextualFallbackResponse(lastUserMessage, language);
    return res.status(200).json({ reply: fallbackReply });
  } catch (error: any) {
    console.error('Serverless chat error:', error);
    return res.status(500).json({ error: 'An error occurred while processing your message.' });
  }
}
